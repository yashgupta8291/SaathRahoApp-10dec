// const express = require('express');
// const http = require('http');
// const { Server } = require('socket.io');
// const mongoose = require('mongoose');
// const Message = require('./models/message'); // Ensure your Message model is correct

// const app = express();
// const server = http.createServer(app);
// const io = new Server(server, {
//   cors: {
//     origin: "*", // Adjust this if needed for specific domains
//   }
// });

// // Connect to MongoDB
// mongoose.connect('mongodb+srv://roomieqindiawork:roomie123@cluster0.iilrg.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
//   .then(() => console.log("MongoDB connected successfully"))
//   .catch((err) => console.error("MongoDB connection error:", err));

// io.on('connection', (socket) => {
//   console.log('User connected:', socket.id);

//   socket.on('join_room', async (roomId) => {
//     socket.join(roomId);
//     console.log(`User joined room: ${roomId}`);

//     // Load previous messages
//     try {
//       const messages = await Message.find({ roomId }).sort({ timestamp: 1 });
//       socket.emit('load_previous_messages', messages);
//     } catch (error) {
//       console.error('Error loading messages:', error);
//     }
//   });

//   socket.on('send_message', async (data) => {
//     const newMessage = new Message({
//       roomId: data.roomId,
//       senderId: data.senderId,
//       receiverId: data.receiverId,
//       message: data.message,
//       timestamp: new Date(),
//     });
    
//     try {
//       await newMessage.save();
//       io.to(data.roomId).emit('receive_message', newMessage); // Emit to all clients in the room
//     } catch (error) {
//       console.error('Error saving message:', error);
//     }
//   });

//   socket.on('disconnect', () => {
//     console.log('User disconnected:', socket.id);
//   });
// });

// server.listen(8000, () => {
//   console.log('Server is running on port 8000');
// });
