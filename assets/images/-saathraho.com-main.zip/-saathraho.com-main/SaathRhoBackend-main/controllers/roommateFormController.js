const RoommateForm = require('../models/RoommateForm');

// Create a new Roommate Listing
const createRoommate = async (req, res) => {
    try {
        const newRoommate = new RoommateForm(req.body);
        await newRoommate.save();
        res.status(201).json({
            message: 'Roommate listing created successfully',
            roommate: newRoommate
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error', error });
    }
};

// Get all Roommate Listings
const getAllRoommates = async (req, res) => {
    try {
        const roommates = await RoommateForm.find();
        res.status(200).json(roommates);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error', error });
    }
};

// Get a Roommate Listing by ID
const getRoommateById = async (req, res) => {
    try {
        const roommate = await RoommateForm.findById(req.params.id);
        if (!roommate) {
            return res.status(404).json({ message: 'Roommate listing not found' });
        }
        res.status(200).json(roommate);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error', error });
    }
};

// Update a Roommate Listing
const updateRoommate = async (req, res) => {
    try {
        const updatedRoommate = await RoommateForm.findByIdAndUpdate(req.params.id, req.body, {
            new: true,
            runValidators: true
        });
        if (!updatedRoommate) {
            return res.status(404).json({ message: 'Roommate listing not found' });
        }
        res.status(200).json({
            message: 'Roommate listing updated successfully',
            roommate: updatedRoommate
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error', error });
    }
};

// Delete a Roommate Listing
const deleteRoommate = async (req, res) => {
    try {
        const deletedRoommate = await RoommateForm.findByIdAndDelete(req.params.id);
        if (!deletedRoommate) {
            return res.status(404).json({ message: 'Roommate listing not found' });
        }
        res.status(200).json({
            message: 'Roommate listing deleted successfully',
            roommate: deletedRoommate
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error', error });
    }
};

module.exports = {
    createRoommate,
    getAllRoommates,
    getRoommateById,
    updateRoommate,
    deleteRoommate
};
