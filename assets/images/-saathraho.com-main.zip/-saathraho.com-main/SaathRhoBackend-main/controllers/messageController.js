const mongoose = require('mongoose');
const Message = require('../models/message'); 
const User = require('../models/User'); // Import the User model

// Controller to get messages
const getMessages = async (req, res) => {
  const { useruid } = req.query;  // Get the useruid from query parameters

  try {
    // Validate if useruid is provided
    if (!useruid) {
      return res.status(400).json({ error: "User ID is required." });
    }

    // Step 1: Retrieve messages where the user is either the sender or receiver
    const messages = await Message.find({
      $or: [{ senderId: useruid }, { receiverId: useruid }]  // Compare with senderId or receiverId
    });

    // If no messages found, return an empty array
    if (messages.length === 0) {
      return res.status(200).json([]);
    }
    console.log(useruid);
    // Step 2: Fetch the user information based on the useruid
    const user = await User.findOne({ uid: useruid });
    console.log(user);
    // Compare the custom 'uid' field in User model
    if (!user) {
      return res.status(404).json({ error: "User not found." });
    }

    // Step 3: Map through messages and add user info to each message
    const messageWithUserInfo = await Promise.all(messages.map(async (message) => {
      // Determine the other user by comparing the sender and receiver
      const otherUserId = message.senderId === useruid ? message.receiverId : message.senderId;
      console.log(otherUserId);
      // Find the other user based on the useruid
      const otherUser = await User.findOne({ uid: otherUserId }).select(); // Adjust fields as needed
      console.log(otherUser);
      return {
        message,
        user: otherUser
      };
    }));

    // Return the messages along with user information
    res.status(200).json(messageWithUserInfo);

  } catch (error) {
    console.error('Error retrieving messages:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

module.exports = {
  getMessages,
};
