const OfficeListingForm = require('../models/OfficeListingForm');

// Create a new Office Listing
const createOfficeListing = async (req, res) => {
    try {
        const newOfficeListing = new OfficeListingForm(req.body);
        await newOfficeListing.save();
        res.status(201).json({
            message: 'Office listing created successfully',
            officeListing: newOfficeListing
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error', error });
    }
};

// Get all Office Listings
const getAllOfficeListings = async (req, res) => {
    try {
        const officeListings = await OfficeListingForm.find();
        res.status(200).json(officeListings);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error', error });
    }
};

// Get an Office Listing by ID
const getOfficeListingById = async (req, res) => {
    try {
        const officeListing = await OfficeListingForm.findById(req.params.id);
        if (!officeListing) {
            return res.status(404).json({ message: 'Office listing not found' });
        }
        res.status(200).json(officeListing);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error', error });
    }
};

// Update an Office Listing
const updateOfficeListing = async (req, res) => {
    try {
        const updatedOfficeListing = await OfficeListingForm.findByIdAndUpdate(req.params.id, req.body, {
            new: true,
            runValidators: true
        });
        if (!updatedOfficeListing) {
            return res.status(404).json({ message: 'Office listing not found' });
        }
        res.status(200).json({
            message: 'Office listing updated successfully',
            officeListing: updatedOfficeListing
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error', error });
    }
};

// Delete an Office Listing
const deleteOfficeListing = async (req, res) => {
    try {
        const deletedOfficeListing = await OfficeListingForm.findByIdAndDelete(req.params.id);
        if (!deletedOfficeListing) {
            return res.status(404).json({ message: 'Office listing not found' });
        }
        res.status(200).json({
            message: 'Office listing deleted successfully',
            officeListing: deletedOfficeListing
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error', error });
    }
};

module.exports = {
    createOfficeListing,
    getAllOfficeListings,
    getOfficeListingById,
    updateOfficeListing,
    deleteOfficeListing
};
