// models/WishList.js

// controllers/wishlistController.js
const WishList = require('../models/WishList');
const Property = require('../models/Property'); // Adjust the path according to your project structure


// Add to wishlist logic
const addToWishlist = async (req, res) => {
    const { UserUid, PropertyUid } = req.body;

    try {
        // Find the wishlist item by PropertyUid
        const existingWishList = await WishList.findOne({ PropertyUid });

        if (existingWishList) {
            // Check if UserUid is already in the array
            if (existingWishList.UserUid.includes(UserUid)) {
                return res.status(400).json({ message: 'Property already in wishlist for this user.' });
            }

            // Add UserUid to the existing UserUid array
            existingWishList.UserUid.push(UserUid);
            await existingWishList.save(); // Save the updated wishlist

            return res.status(200).json({
                message: 'User added to existing property in wishlist successfully',
                wishList: existingWishList
            });
        }

        // If the property does not exist, create a new wishlist entry
        const newWishList = new WishList({
            UserUid: [UserUid], // Store UserUid as an array
            PropertyUid
        });

        await newWishList.save();

        res.status(201).json({
            message: 'Property added to wishlist successfully',
            wishList: newWishList
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error', error });
    }
};

// Remove from wishlist logic
const removeFromWishlist = async (req, res) => {
    const { UserUid, PropertyUid } = req.body;

    try {
        // Find the wishlist item by PropertyUid
        const wishListItem = await WishList.findOne({ PropertyUid });

        if (!wishListItem) {
            return res.status(404).json({ message: 'Property not found in wishlist' });
        }

        // Check if UserUid is part of the UserUid array
        if (!wishListItem.UserUid.includes(UserUid)) {
            return res.status(400).json({ message: 'UserUid not found in the wishlist' });
        }

        // Remove the user from the UserUid array
        wishListItem.UserUid = wishListItem.UserUid.filter(uid => uid !== UserUid);
        
        // If UserUid array becomes empty, delete the entire wishlist item
        if (wishListItem.UserUid.length === 0) {
            await WishList.deleteOne({ PropertyUid });
        } else {
            await wishListItem.save(); // Save the updated wishlist item
        }

        res.status(200).json({ message: 'Property removed from wishlist successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error', error });
    }
};

// Get wishlist for a user logic
const getWishlist = async (req, res) => {
    const { userUid, propertyUid } = req.body; // Get userUid and propertyUid from the request body

    try {
        // Find the wishlist item by PropertyUid
        const wishListItem = await WishList.findOne({ PropertyUid: propertyUid });

        // Check if the wishlist item exists
        if (!wishListItem) {
            return res.status(404).json({ message: 'Property not found in wishlist.' });
        }

        // Check if the userUid is in the UserUid array of that wishlist item
        if (!wishListItem.UserUid.includes(userUid)) {
            return res.status(404).json({ message: 'User is not in the wishlist for this property.' });
        }

        // Find the property in the properties collection using propertyUid
        const property = await Property.findOne({ PropertyUid: propertyUid }); // Adjust according to your property ID field

        // Check if the property exists
        if (!property) {
            return res.status(404).json({ message: 'Property not found.' });
        }

        res.status(200).json({
            message: 'User found in wishlist for this property.',
            wishlist: wishListItem,
            property // Return the full property object
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error', error });
    }
};

const getUserWishlistProperties = async (req, res) => {
    const { userId } = req.query; // Get userId from the query parameters

    try {
        // Find all wishlist items that include the userId
        const wishListItems = await WishList.find({ UserUid: userId }); // Adjust according to your UserUid field

        // Check if the wishlist items exist
        if (!wishListItems.length) {
            return res.status(404).json({ message: 'No properties found in wishlist for this user.' });
        }

        // Extract the property UIDs from the wishlist items
        const propertyUids = wishListItems.map(item => item.PropertyUid);

        // Find the properties corresponding to the property UIDs
        const properties = await Property.find({ PropertyUid: { $in: propertyUids } }); // Adjust according to your property ID field

        // Check if any properties were found
        if (!properties.length) {
            return res.status(404).json({ message: 'No properties found.' });
        }

        res.status(200).json({
            message: 'Properties found for the user in their wishlist.',
            properties // Return the array of property objects
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error', error });
    }
};


// Export the functions
module.exports = {
    addToWishlist,
    removeFromWishlist,
    getWishlist,
    getUserWishlistProperties
};
