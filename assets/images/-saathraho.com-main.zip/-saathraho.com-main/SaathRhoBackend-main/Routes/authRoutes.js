// In your router file (e.g., authRoutes.js)
const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

// Route for signup
router.post('/signup', authController.signup);

// Route for verifying OTP
router.post('/verify-otp', authController.verifyOTP);

// Route for login
router.post('/login', authController.login);
router.post('/updateName', authController.updateUserName);
router.post('/updateAddress', authController.updateUserAddress);

router.post('/initiate-email-update', authController.initiateEmailUpdate);
router.post('/verify-email-update', authController.verifyAndUpdateEmail);
router.post('/initiate-phone-update', authController.initiatePhoneUpdate);
router.post('/verify-phone-update', authController.verifyAndUpdatePhone);
router.post('/initiate-password-update', authController.initiatePasswordUpdate);
router.post('/verify-password-update', authController.verifyAndUpdatePassword);

// Route for forget password
router.post('/forget-password', authController.forgetPassword); // Add this line

router.post('/verify-password-reset-otp', authController.verifyPasswordResetOTP); // Add this line


module.exports = router;
