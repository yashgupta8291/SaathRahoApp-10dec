const express = require('express');
const { getMessages } = require('../controllers/messageController');
const router = express.Router();

// Get messages for a user
router.get('/messages', getMessages);

module.exports = router;
