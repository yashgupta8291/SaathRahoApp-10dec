const mongoose = require('mongoose');

const wishListSchema = new mongoose.Schema({
    UserUid: { type: [String], required: true }, // Array of User UIDs
    PropertyUid: { type: String, required: true }, // Unique identifier for the property
}, { timestamps: true }); // Automatically adds createdAt and updatedAt timestamps

module.exports = mongoose.model('WishList', wishListSchema);
