// models/User.js

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const purchaseSchema = new mongoose.Schema({
    purchaseDate: { type: Date, required: true },
    purchasePrice: { type: Number, required: true },
    purchasePlan: { type: String, required: true },
    isCouponApplied: { type: Boolean, default: false },
    finalPrice: { type: Number }
});

const userSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    profilePic: { type: String },
    uid: { type: String, required: true, unique: true },
    phoneNo: { type: String },
    password: { type: String, required: true },
    pincode: { type: String },
    address: { type: String },
    purchases: [purchaseSchema]
});

// Hash the password before saving
userSchema.pre('save', async function (next) {
    if (!this.isModified('password')) return next();
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
});

module.exports = mongoose.model('User', userSchema);
