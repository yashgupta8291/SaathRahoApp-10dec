const mongoose = require('mongoose');

const roommateFormSchema = new mongoose.Schema({
    Name: { type: String, required: true },
    Location: { type: String, required: true },
    userUid: { type: String, required: true },
    Hometown: { type: String, required: true },
    RoomPreference: { type: String, required: true }, // e.g., "Single", "Shared"
    LanguagePreference: { type: String, required: true },
    PreferredGender: { type: String, enum: ['Male', 'Female', 'Any'], required: true },
    Occupation: { type: String, required: true },
    MoveInDetails: { type: String, required: true }, // e.g., "Immediate", "Next Month"
    LocationPreference: { type: String, required: true },
    Interests: [{ type: String }], // Array of interests
    Description: { type: String, required: true },
    Image: { type: String },
    isApproved: { type: Boolean, default: false },
    FeatureListing: [
        {
            Uid: { type: String, required: false }
        }
    ],
    CategoryType: { type: String, default: 'Roomate' }, // URL or path to image
}, { timestamps: true });

module.exports = mongoose.model('RoommateForm', roommateFormSchema);
