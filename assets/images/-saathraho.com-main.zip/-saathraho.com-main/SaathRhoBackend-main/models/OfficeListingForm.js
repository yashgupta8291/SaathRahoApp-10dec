const mongoose = require('mongoose');

const officeListingFormSchema = new mongoose.Schema({
    OfficeName: { type: String, required: true },
    userUid:{type: String, required :true},
    OfficeLocation: { type: String, required: true },
    OfficeTitle: { type: String, required: true },
    OfficeMonthlyMaintenance: { type: String, required: true },
    OfficeFloorNo: { type: String, required: true },
    OfficeTotalFloor: { type: String, required: true },
    CarpetArea: { type: String, required: true }, // In square feet or meters
    OfficeFacing: { type: String, required: true },
    OfficeDeposit: { type: String, required: true },
    ParkingAvailable: { type: String, required: true },
    NoOfCabins: { type: String, required: true },
    NoOfBathrooms: { type: String, required: true },
    Furnished: { type: String, required: true },
    categoryType: { type: String, required: true },
    ListedBy: { type: String, required: true },
    CategoryType: { type: String, default: 'Office' },
    Amenities: [{ type: String }],
    OfficeDescription: { type: String, required: true },
    isApproved: { type: Boolean, default: false },
    OfficeImages: [{ type: String }], // Array of URLs to images
}, { timestamps: true });

module.exports = mongoose.model('OfficeListingForm', officeListingFormSchema);
