const mongoose = require('mongoose');

const hostelDetailsFormSchema = new mongoose.Schema({
    HostelName: { type: String, required: true },
    HostelDes: { type: String, required: true },
    rent: { type: String, required: true },
    location: { type: String, required: true },
    maintainace: { type: String, required: true },
    timing: { type: String, required: true },
    totalfloor: { type: String, required: true },
    deposit: { type: String, required: true },
    gender: { type: String, required: true },
    bathrom: { type: String, required: true },
    dining: { type: String, required: true },
    furnished: { type: String, required: true },
    categoryType: { type: String, required: true },
    parking: { type: String, required: true },
    userUid: { type: String, required: true },
    sharing: { type: String, required: true },
    electricity: { type: String, required: true },
    visitors: { type: String, required: true },
    images: [{ type: String }],  // specify String type for array
    Amenities: [{ type: String }],
    FeatureListing: [
        {
            Uid: { type: String, required: false }
        }
    ] ,  // specify String type for array
    isApproved: { type: Boolean, required: true, default: false }, // Corrected to Boolean
    Uid: { type: String, required: true, unique: true } // Unique identifier for the hostel
}, { timestamps: true });

module.exports = mongoose.model('HostelDetailsForm', hostelDetailsFormSchema);
