const mongoose = require('mongoose');

const bhojnalayaSchema = new mongoose.Schema({
    BhojnalayaImages: { type: [String], default: [] }, // Array of image URLs for the Bhojnalaya
    userUid: { type: String, required: true },
    BhojnalayaName: { type: String, required: true },
    CategoryType: { type: String, default: 'Bhojnalaya' },
    MonthlyCharge1: { type: String, required: true },
    Amenities: { type: [String], default: [] }, // Array of amenities
    Parking: { type: String, default: false },
    SpecialThali: { type: String, default: false },
    MonthlyCharge2: { type: String },
    PriceOfThali: { type: String },
    Timings: { type: String, required: true },
    location: { type: String, required: true },
    VegOrNonVeg: { type: String, required: true },
    ParcelOfFood: { type: String, default: false },
    Description: { type: String },
    isApproved: { type: Boolean, default: false },
    FeatureListing: [
        {
            Uid: { type: String, required: false }
        }
    ],
    Uid: { type: String, required: true, unique: true } // Unique identifier for the Bhojnalaya
}, { timestamps: true }); // Automatically adds createdAt and updatedAt timestamps

module.exports = mongoose.model('Bhojnalaya', bhojnalayaSchema);
