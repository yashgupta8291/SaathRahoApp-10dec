import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Logo from "../assets/FinalLogo.png";
import triangle from "../assets/triangle.png";
import { useAuth } from "../../utils/LoginContext";
import LoginComponent from "../components/login";

function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isLoginVisible, setLoginVisible] = useState(false);
  const [isDropdownOpen, setDropdownOpen] = useState(false);
  const { state } = useAuth();
  const isLoggedin = state.isLoggedIn;

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 0);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleDropdown = () => setDropdownOpen(!isDropdownOpen);

  return (
    <div className="relative">
      {/* Navbar */}
      <nav
        className={`fixed w-full z-[100] transition-shadow duration-300 ${
          isScrolled ? "bg-white shadow-lg" : "bg-[#D0F4DE]"
        }`}
      >
        <div className="mx-auto flex items-center justify-between px-2 sm:px-4 lg:px-6 h-[70px] sm:h-[90px] lg:h-[110px]">
          {/* Logo */}
          <Link to="/home">
            <img
              src={Logo}
              alt="Logo"
              className="w-[100px] h-[80px] sm:w-[120px] sm:h-[90px] lg:w-[160px] lg:h-[110px]"
            />
          </Link>

          {/* Navigation & Actions */}
          <div className="flex items-center space-x-3 sm:space-x-6">

            <Link to="">
              <button className="btn bg-[#FCF6BD] shadow-md border-b-4 border-slate-300 py-1 px-2 sm:py-2 sm:px-6 rounded-full">
                <span className="text-black text-xs sm:text-base lg:text-lg">
                  Add Listing
                </span>
              </button>
            </Link>

            {isLoggedin ? (
              <ProfileDropdown
                isOpen={isDropdownOpen}
                toggleDropdown={toggleDropdown}
              />
            ) : (
              <>
                <label
                  htmlFor="login_modal"
                  className="btn bg-[#A9DEF9] shadow-md border-b-4 border-slate-300 py-2 px-6 rounded-full text-sm sm:text-lg lg:text-xl"
                >
                  Login
                </label>
                <input type="checkbox" id="login_modal" className="modal-toggle" />
                <div className="modal !m-0">
                  <div className="modal-box h-[600px]">
                    <LoginComponent />
                  </div>
                  <label htmlFor="login_modal" className="modal-backdrop">
                    Close
                  </label>
                </div>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Login Modal */}
      {isLoginVisible && (
        <div
          className="fixed inset-0 bg-[#0000002b] backdrop-blur-md z-40 h-full flex items-center justify-center"
          onClick={() => setLoginVisible(false)}
        >
          <div className="bg-white rounded-2xl shadow-lg p-6 w-11/12 sm:w-3/4 lg:w-1/3 relative">
            <LoginComponent />
          </div>
        </div>
      )}
    </div>
  );
}

// eslint-disable-next-line react/prop-types
const ProfileDropdown = ({ isOpen, toggleDropdown }) => (
  <div className="relative">
    <div onClick={toggleDropdown} className="cursor-pointer flex items-center">
      <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full overflow-hidden">
        <img
          src="https://img.daisyui.com/images/stock/photo-1534528741775-53994a69daeb.webp"
          alt="Profile"
          className="object-cover w-full h-full"
        />
      </div>
    </div>
    {isOpen && (
      <div className="absolute right-0 mt-2 bg-gradient-to-b from-[#e2f4c9] to-[#F5FABF] rounded-lg shadow-lg w-[250px] sm:w-[300px] z-50">
        <div className="p-4 flex flex-col space-y-3">
          <div className="flex items-center justify-between">
            <img src={triangle} className="absolute top-[-15px] left-10" alt="" />
            <img src={Logo} alt="Logo" className="w-8 h-8 sm:w-10 sm:h-10" />
            <p className="text-sm sm:text-lg lg:text-xl font-medium text-gray-700">
              Hi!
            </p>
            <button
              onClick={toggleDropdown}
              className="text-lg sm:text-xl lg:text-2xl font-bold text-gray-500"
            >
              &times;
            </button>
          </div>
          <ul className="space-y-2 text-gray-700">
            <li className="border-b pb-2">
              <Link to="#">Edit Profile</Link>
            </li>
            <li className="border-b pb-2">
              <Link to="#">My Listing</Link>
            </li>
            <li className="border-b pb-2">
              <Link to="#">My Wishlist</Link>
            </li>
            <li className="border-b pb-2">
              <Link to="#">Coupons & Rewards</Link>
            </li>
            <li className="border-b pb-2">
              <Link to="#" className="text-red-500">
                Logout
              </Link>
            </li>
          </ul>
        </div>
      </div>
    )}
  </div>
);

export default Navbar;
