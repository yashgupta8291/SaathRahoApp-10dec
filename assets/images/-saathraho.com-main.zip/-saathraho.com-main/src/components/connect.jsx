import React from 'react'

function connect() {
  return (
    <div>connect</div>
  )
}

export default connect