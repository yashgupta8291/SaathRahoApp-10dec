import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Close from "../assets/closeicon.svg";
import Logo from "../assets/Logo.svg";
import { useAuth } from "../../utils/LoginContext";

const LoginForm = () => {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [errors, setErrors] = useState({});
  const { dispatch } = useAuth();
  const [success, setSuccess] = useState("");
  const navigate = useNavigate(); // Initialize navigate function
  const backendUrl = import.meta.env.VITE_URL;

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    setErrors({ ...errors, [e.target.name]: "" }); // Clear error on change
  };

  const validateForm = () => {
    const newErrors = {};
    // Full Name validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email) {
      newErrors.email = "Email is required";
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = "Email is not valid";
    }
    if (!formData.password) {
      newErrors.password = "Password is required";
    } else if (formData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0; // Return true if no errors
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;
    const newErrors = {};
    try {
      const response = await fetch(`${backendUrl}/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        newErrors.sub = data.message || "Login failed. Please check your credentials.";
        setErrors(newErrors);
        return;
      }
      // On successful login
      setSuccess("Login successful!");
      localStorage.setItem("isLoggedIn", "true");
      dispatch({ type: "LOGIN" });
      // Set login status in localStorage
      if (data.uuid) {
        localStorage.setItem("userUUID", data.uuid); // Store the UUID
      }

      // Redirect to home page after 1 second
      setTimeout(() => {
        navigate("/home", {
          state: { email: formData.email },
        });
      }, 1000);
    } catch (error) {
      console.error("Error logging in:", error);
      newErrors.sub = "An Unexpected Error Occurred!";
      setErrors(newErrors);
    }
  };

  return (
    <div className="min-h-screen bg-gray-300 flex items-center justify-center font-poppins">
      <div className="bg-white rounded-2xl p-8 w-full max-w-md h-full relative flex flex-col">
        {/* Close button */}
        <Link to="/home">
          <button className="absolute right-9 top-10 text-gray-400 hover:text-gray-600">
            <img src={Close} alt="" className="h-8 w-8" />
          </button>
        </Link>

        {/* Logo and Title */}
        <div className="flex items-center gap-2 mb-6">
          <div className="rounded-lg">
            <img src={Logo} alt="Logo" className="w-10 h-10" />
          </div>
          <h1 className="text-2xl md:text-3xl ml-[-50px] font-semibold flex-grow text-center">
            Login
          </h1>
        </div>

        {/* Form Fields */}
        <form className="flex-1 flex flex-col justify-between">
          <div className="space-y-4">
            <div>
              <input
                type="email"
                name="email"
                placeholder="Email"
                className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-purple-200 text-md"
                value={formData.email}
                onChange={handleChange}
              />
              {errors.email && (
                <p className="text-red-500 text-xs">{errors.email}</p>
              )}
            </div>

            {/* Password Field */}
            <div>
              <input
                type="password"
                name="password"
                placeholder="Password"
                className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-purple-200 text-md"
                value={formData.password}
                onChange={handleChange}
              />
              {errors.password && (
                <p className="text-red-500 text-xs">{errors.password}</p>
              )}
            </div>

            {/* Terms Text */}
            <p className="text-[10px] text-gray-500 ml-[10px] relative top-1">
              By Tapping login, you accept terms & conditions, legal notice, and
              privacy policy.
            </p>
          </div>

          <div className="space-y-4">
            {/* Buttons */}
            <button
              type="button"
              onClick={handleSubmit}
              className="w-full py-2 bg-[#E4C1F9] text-purple-700 rounded-lg hover:bg-purple-300 transition-colors text-sm font-medium relative top-4 h-10"
            >
              <p className="text-[20px] text-slate-500 relative font-light">
                Login
              </p>
            </button>
            {errors.password && (
                <p className="text-red-500 text-xs my-1">{errors.sub}</p>
              )}
            {success && (
              <p className="text-green-500 text-xs my-1">{success}</p>
            )}  
            <div className="flex items-center gap-2 my-2 relative top-4">
              <div className="flex-1 h-px bg-gray-300"></div>
              <span className="text-xs text-gray-500">or</span>
              <div className="flex-1 h-px bg-gray-300"></div>
            </div>

            <button
              type="button"
              className="w-full py-2 bg-[#E4C1F9] text-purple-700 rounded-lg hover:bg-purple-300 transition-colors flex items-center justify-center gap-2 text-sm font-medium relative top-4 h-10"
            >
              <img
                src="https://cdn.cdnlogo.com/logos/g/35/google-icon.svg"
                alt="Google logo"
                className="w-6 h-6"
              />
              <p className="text-[20px] text-slate-500 relative font-light">
                Sign in with Google{" "}
              </p>
            </button>

            <div className="h-[1px] w-full bg-slate-200 relative top-4"></div>

            {/* Login Link */}
            <div className="ml-[10px]">
              <span className="sm:text-xs text-[10px] text-gray-500 font-light">
                Create an account?{" "}
              </span>
              <Link
                to="/signup"
                className="sm:text-xs text-[10px] text-gray-700 "
              >
                Signup
              </Link>
              <div className="sm:text-xs text-[10px] text-gray-500 font-light relative sm:right-[-265px] right-[-207px] top-[-17px]">
                Forgot Password?
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginForm;
