import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Close from "../assets/closeicon.svg";
import Logo from "../assets/Logo.svg";
import { useAuth } from "../../utils/LoginContext";

const Login = () => {
  const { dispatch } = useAuth();
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [isModalVisible, setModalVisible] = useState(true);
  const navigate = useNavigate();
  const backendUrl = import.meta.env.VITE_URL;

  const handleChange = (e) => {
    setError("");
    setSuccess("");
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!formData.email || !formData.password) {
      setError("Please fill in all fields.");
      return;
    }

    try {
      const response = await fetch(`${backendUrl}/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.message || "Login failed. Please check your credentials.");
        return;
      }

      // On successful login
      setSuccess("Login successful!");
      localStorage.setItem("isLoggedIn", "true");
      dispatch({ type: "LOGIN" });
      if (data.uuid) {
        localStorage.setItem("userUUID", data.uuid);
      }

      // Redirect to home page
      setTimeout(() => {
        navigate("/home", {
          state: { email: formData.email },
        });
      }, 1000);
    } catch (error) {
      console.error("Error logging in:", error);
      setError("An error occurred. Please try again later.");
    }
  };

  const closeModal = () => {
    setModalVisible(false);
    window.location.reload();
  };

  return (
    isModalVisible && (
      <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
        <div className="bg-white rounded-xl shadow-lg p-6 w-full max-w-md relative">
          <button
            onClick={closeModal}
            className="absolute top-4 right-4 p-2 hover:bg-gray-100 rounded-full"
          >
            <img src={Close} alt="Close" className="h-6 w-6" />
          </button>

          <div className="text-center mb-6">
            <img src={Logo} alt="Logo" className="mx-auto w-12 h-12" />
            <h2 className="text-2xl font-semibold mt-2">Login</h2>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="email"
              name="email"
              placeholder="Email"
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-300"
              value={formData.email}
              onChange={handleChange}
              required
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-300"
              value={formData.password}
              onChange={handleChange}
              required
            />
            {error && <p className="text-sm text-red-500">{error}</p>}
            {success && <p className="text-sm text-green-500">{success}</p>}

            <button
              type="submit"
              className="w-full bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700 transition duration-200"
            >
              Login
            </button>

            <div className="text-center text-sm text-gray-500 mt-4">
              <p>
                By tapping Login, you accept our{" "}
                <span className="underline">Terms</span> and{" "}
                <span className="underline">Privacy Policy</span>.
              </p>
            </div>
          </form>

          <div className="mt-6">
            <button
              type="button"
              className="w-full flex items-center justify-center bg-gray-100 py-2 rounded-lg hover:bg-gray-200 transition duration-200"
            >
              <img
                src="https://cdn.cdnlogo.com/logos/g/35/google-icon.svg"
                alt="Google"
                className="h-5 w-5 mr-2"
              />
              Sign in with Google
            </button>
          </div>

          <div className="mt-6 text-center text-sm">
            <p>
              Don’t have an account?{" "}
              <Link to="/signup" className="text-purple-600 hover:underline">
                Register
              </Link>
            </p>
          </div>

          <div className="text-center text-sm mt-4">
            <Link
              to="/forgot"
              className="text-purple-600 hover:underline"
            >
              Forgot Password?
            </Link>
          </div>
        </div>
      </div>
    )
  );
};

export default Login;
