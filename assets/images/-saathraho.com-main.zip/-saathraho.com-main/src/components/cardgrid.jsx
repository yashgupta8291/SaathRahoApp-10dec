import Heart from "../assets/Right.svg";
import Right from "../assets/Heart.svg";

const GridComponent = () => {
  return (
    <div className="font-poppins px-4 sm:px-8 py-6">
      {/* Grid Container */}
      <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Array.from({ length: 9 }).map((_, index) => (
          <div
            key={index}
            className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300"
          >
            {/* Image Section */}
            <div className="bg-[#d9d9d9] h-[120px] sm:h-[200px] rounded-t-2xl relative">
            <div className="absolute top-4 right-4 flex gap-2">
            <img src={Right} alt="" className="w-5 h-5 md:w-8 md:h-8" />
            <img src={Heart} alt="" className="w-5 h-5 md:w-8 md:h-8" />
          </div>
            </div>

            {/* Content Section */}
            <div className="bg-[#fcf6bd] rounded-b-2xl p-4 flex flex-col justify-between">
              {/* Title and Description */}
              <div className="hidden sm:block">
                <h1 className="text-xl font-semibold mb-2">Title for the category</h1>
                <p className="text-gray-700 text-sm mb-4 leading-relaxed">
                  Description for the category
                </p>
              </div>

              {/* Price and Location */}
              <div className="flex flex-col sm:flex-row justify-between items-center">
                <h1 className="text-base sm:text-lg font-medium">INR 2000/-</h1>
                <p className="text-xs mt-1 sm:mt-0 text-gray-500">City/area, State</p>
              </div>

              {/* Button */}
              <button className="bg-[#a9def9] text-xs sm:text-base mt-4 px-6 py-2 rounded-full hover:bg-[#87cce6] transition-colors duration-300 font-medium border-b-[2px] border-gray-300">
                Contact Now
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default GridComponent;
