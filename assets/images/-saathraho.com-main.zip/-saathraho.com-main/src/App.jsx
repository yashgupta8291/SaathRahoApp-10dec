import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/home";
import Testing from "./pages/nolistingpage";
import Signup from "./components/signup";
import Cat1 from "./pages/categorypagebefore";
import Cat from "./pages/categorypage";
// import Cat2 from "./pages/categorypageafter";
import OTP1 from "./pages/otp";
// import OTP2 from "./pages/otp2";
import CityPage from "./pages/finalcitypage";
import WishList from "./pages/finalwishlist";
import Coupon_Reward from "./pages/couponandreward";
import Profile from "./pages/profile";
import BlogPage from "./pages/blogpage";
import RoomListingPage from "./pages/roomlistingpage";
import RoomListingForm from "./pages/roomlistingform";
import Membership from "./pages/membership";
import MembershipPage from "./pages/membershippage";
import AboutUs from "./pages/aboutus";
import CareerWithUS from "./pages/careerpage";
import BlogSubPage from "./pages/blogsubpage";
import PrivacyPolicy from "./pages/privacypolicy";
import TermsCondition from "./pages/termscondition";
import LegalNotice from "./pages/legalnotice";
import Support from "./pages/supportpage";
import AddListing from "./pages/addlisting";
import RoomMateListing from "./pages/roommatelisting";
import RoomMateForm from "./pages/roommateform";
import BhojnalaySubPage from "./pages/bhojnalaysubpage";
import BhojnalayForm from "./pages/bhojnalayform";
import HostelListingPage from "./pages/hostellistingpage";
import HostelListingForm from "./pages/hostellistingform";
import OfficeListingPage from "./pages/officelistingpage";
import OfficeListingForm from "./pages/officelistingform";
import Logout from "./components/logout";
import DltAcc from "./components/dltacc";
import Chatpage from "./pages/chatpage";
import Notfoundpage from "./pages/notfoundpage";
import Loader from "./pages/loader";

import LoginForm from "./components/loginpage";
import ChatRoom from "./components/ChatRoom";

// import Cards from "./components/cards";

export default function App() {
  return (
    <Router>
      <Routes>
        {/* Define your routes here */}
        <Route path="/testing" element={<Testing />} />
        <Route path="/home" element={<Home />} />
        <Route path="/login" element={<LoginForm />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/cat1" element={<Cat1 />} />
        {/* <Route path="/cat2" element={<Cat2 />} /> */}
        <Route path="/cat" element={<Cat />} />
        <Route path="/otp1" element={<OTP1 />} />
        {/* <Route path="/otp2" element={<OTP2 />} /> */}
        <Route path="/citypage" element={<CityPage />} />
        <Route path="/wishlist" element={<WishList />} />
        <Route path="/couponandreward" element={<Coupon_Reward />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/blogpage" element={<BlogPage />} />
        <Route path="/roomlistingpage" element={<RoomListingPage />} />
        <Route path="/roomlistingform" element={<RoomListingForm />} />
        <Route path="/membership" element={<Membership />} />
        <Route path="/membershippage" element={<MembershipPage />} />
        <Route path="/aboutus" element={<AboutUs />} />
        <Route path="/careerpage" element={<CareerWithUS />} />
        <Route path="/blogsubpage" element={<BlogSubPage />} />
        <Route path="/privacypolicy" element={<PrivacyPolicy />} />
        <Route path="/termscondition" element={<TermsCondition />} />
        <Route path="/legalnotice" element={<LegalNotice />} />
        <Route path="/supportpage" element={<Support />} />
        <Route path="/addlisting" element={<AddListing />} />
        <Route path="/roommatelisting" element={<RoomMateListing />} />
        <Route path="/roommatelistingform" element={<RoomMateForm />} />
        <Route path="/bhojnalaysubpage" element={<BhojnalaySubPage />} />
        <Route path="/bhojnalayform" element={<BhojnalayForm />} />
        <Route path="/hostellistingpage" element={<HostelListingPage />} />
        <Route path="/hostellistingform" element={<HostelListingForm />} />
        <Route path="/officelistingpage" element={<OfficeListingPage />} />
        <Route path="/officelistingform" element={<OfficeListingForm />} />
        <Route path="/logout" element={<Logout />} />
        <Route path="/dltacc" element={<DltAcc />} />
        <Route path="/chatpage" element={<Chatpage />} />
        <Route path="/chatpage/:roomId" element={<ChatRoom />} />
        <Route path="/notfoundpage" element={<Notfoundpage />} />
        <Route path="/loader" element={<Loader />} />
        {/* <Route path="/Bot" element={<Bot />} /> */}
        
        {/* <Route path="/cards" element={<Cards />} /> */}

      </Routes>
    </Router>
  );
}
