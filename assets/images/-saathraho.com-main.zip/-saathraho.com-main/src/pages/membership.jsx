import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom"; // Import Link
import Logo from "../assets/Logo.svg";
import img from "../assets/membership.png";


function Membership() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <div className="w-full max-w-screen-xl mx-auto bg-white py-10 px-4 font-poppins">
      <div className="flex items-center justify-between max-w-full">
        <div
          className={`w-[1540px] h-[130px] bg-white fixed z-50 transition-shadow duration-300 ${
            isScrolled ? "shadow-lg" : ""
          } left-[-20px]`}
        >
          <img
            className="w-[70px] h-[70px] fixed z-55 mt-[40px] ml-[60px]"
            src={Logo}
            alt="Logo"
          />
          <button className="pl-[17px] pr-4 py-[13px] left-[1035px] top-[35px] fixed z-50 bg-[#fcf6bd] rounded-[50px] border-b-4 border-slate-300 justify-center items-center inline-flex w-[200px] shadow h-[55px]">
            <div className="text-black text-2xl font-light font-['Poppins']">
              Add Listing
            </div>
          </button>
          <Link to="/login">
            <button className="w-[200px] h-[55px] left-[1250px] top-[34px] fixed z-50 bg-[#d0f4de] rounded-[50px] border-b-4 border-slate-300 shadow">
              <div className="left-[66px] top-[11px] text-black text-2xl font-light font-['Poppins']">
                Log-in
              </div>
            </button>
          </Link>
        </div>
      </div>
      <img src={img} alt="" className="mt-[100px]" />
    </div>
  );
}

export default Membership;
