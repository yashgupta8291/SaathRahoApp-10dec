import React, { useState } from "react";
import fitness from "../assets/fitness.svg";
import travel from "../assets/travel.svg";
import alcohol from "../assets/alcohol.svg";
import party from "../assets/party.svg";
import sport from "../assets/sport.svg";
import read from "../assets/read.svg";
import video from "../assets/video.svg";
import sing from "../assets/sing.svg";
import dance from "../assets/dance.svg";
import food from "../assets/food.svg";
import upload from "../assets/upload.svg";
import Navbar from "../components/Navbar";

function RoomLisitngForm() {

  const [activeButton, setActiveButton] = useState(null);

  // Function to handle button click
  const handleButtonClick = (buttonName) => {
    setActiveButton(buttonName);
  };
  
  const [formData, setFormData] = useState({
    HostelName: '',
    HostelDes: '',
    rent: '',
    location: '',
    maintainace: '',
    timing: '',
    totalfloor: '',
    deposit: '',
    gender: '',
    bathrom: '',
    dining: '',
    furnished: '',
    categoryType: '',
    parking: '',
    userUid: '',
    sharing: '',
    electricity: '',
    visitors: '',
    images: [],
    Amenities: [],
    isApproved: false,
    Uid: '',
});

const [message, setMessage] = useState('');
const [isError, setIsError] = useState(false);

const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
};

const handleSubmit = async (e) => {
    e.preventDefault();
    try {
        const response = await axios.post('http://localhost:5000/api/Createhostels', formData);
        setMessage(response.data.message);
        setIsError(false);
    } catch (error) {
        setMessage(error.response?.data?.message || 'An error occurred.');
        setIsError(true);
    }
};


  const handleGenderSelect = (gender) => {
    setSelectedGender(gender);
  };

  const handleTitleChange = (e) => {
    const value = e.target.value;
    if (value.length <= 25) {
      setTitle(value);
    }
  };


  const [selected, setSelected] = useState(null);

  const handleClick = (index) => {
    setSelected(index);
  };

  const handleDescriptionChange = (e) => {
    const value = e.target.value;
    if (value.length <= 800) {
      // Limit to 800 characters
      setDescription(value);
    }
  };

  return (
    <>
      <Navbar />
      <div className="relative flex flex-col items-center justify-center pt-[300px] pb-8 h-auto text-center z-10">
        <h1 className="text-xl md:text-[40px] font-bold mb-2 text-gray-600">
          Add Your Hostel Details
        </h1>
        <p className="text-md md:text-2xl text-gray-600">
          so anyone can connect with you
        </p>
      </div>

      <div className="flex flex-col md:flex-row justify-center gap-x-[200px] gap-y-[100px] px-4 pt-[200px]">
        <div className="space-y-6 w-full  md:w-[1000px] max-w-lg">
          {/* Your Name */}
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Your Name
            </p>
            <input
              type="text"
              placeholder="Full Name"
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          

          {/* Hometown */}
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Monthly Rent
            </p>
            <input
              type="text"
              placeholder="e.g., Mumbai, Bhopal......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          {/* Location */}
          <div className="relative">
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Location
            </p>
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="sm:h-6 sm:w-6 h-5 w-5 text-gray-600 relative top-[-18px] sm:top-[-8px]"
                fill="currentColor"
                viewBox="0 0 24 24"
              >
                <path d="M12 2C6.48 2 2 6.48 2 12c0 5.5 10 10 10 10s10-4.5 10-10c0-5.52-4.48-10-10-10zm0 14c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4z" />
              </svg>
            </div>
            <textarea
              placeholder="Add location..."
              className="w-full pl-10 p-4 h-32 border border-gray-300 rounded-[20px] outline-none resize-none font-light text-[18px] md:text-[25px] text-gray-600"
              rows="4"
            ></textarea>
          </div>

          {/* Room Preference */}
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[20px] md:text-[25px] font-poppins">
              Monthly Maintenance
            </p>
            <input
              type="text"
              placeholder="₹ 00, 500, 800, 1000......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          {/* Language Preference */}
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Timings
            </p>
            <input
              type="text"
              placeholder="eg: 6am - 10pm, 10pm - 12pm......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Total Floor
            </p>
            <input
              type="text"
              placeholder="eg: 1st floor, 2nd floor......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Deposit
            </p>
            <input
              type="text"
              placeholder="eg: 15 Days, 1 Month......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

        
          {/* Upload Image Section */}
          <div className="relative pt-[50px]">
            <div
              className="upload-field border-dashed p-6 text-center cursor-pointer bg-[#F7F7F7] rounded-[20px]"
              style={{ width: "100%", height: "400px" }}
            >
              <input
                type="file"
                accept="image/*"
                multiple
                style={{ display: "none" }}
                id="upload-input"
                onChange={(e) => {
                  const file = e.target.files[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onloadend = () => {
                      setImage(reader.result); // Save base64 image data
                    };
                    reader.readAsDataURL(file);
                  }
                }}
              />
              <label
                htmlFor="upload-input"
                className="text-gray-600 font-semibold text-[18px] md:text-[20px]"
              >
                <img
                  src={upload}
                  alt=""
                  className="w-[70%] mx-auto h-[100px]"
                />
              </label>
              {image ? (
                <img
                  src={image}
                  alt="Uploaded"
                  className="mt-4 max-w-full h-[250px] rounded-lg"
                />
              ) : (
                <img
                  src={upload}
                  alt="Upload Icon"
                  className="w-0 h-0 mx-auto"
                />
              )}
            </div>
          </div>
        </div>

        {/* Right section */}
        <div className="space-y-6 w-full md:max-w-lg pt-[10px]">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Bachelor's Allowed */}
        <div>
          <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[23px] font-poppins">
          Category of People
          </p>
          <div className="grid grid-cols-1 gap-4">
            <button
              onClick={() => handleButtonClick('Boys')}
              className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'Boys' ? 'bg-gray-100' : ''}`}
            >
              Boys
            </button>
            <button
              onClick={() => handleButtonClick('Girls')}
              className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'Girls' ? 'bg-gray-100' : ''}`}
            >
              Girls
            </button>
          </div>

          {/* Listed by */}
          <div className="mt-[60px]">
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Bathroom
            </p>
            <div className="grid grid-cols-1 gap-4">
              <button
                onClick={() => handleButtonClick('Sharing')}
                className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'Sharing' ? 'bg-gray-100' : ''}`}
              >
                Sharing
              </button>
              <button
                onClick={() => handleButtonClick('Separate')}
                className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'Separate' ? 'bg-gray-100' : ''}`}
              >
                Separate
              </button>
            </div>
          </div>
        </div>

        {/* No. of Bedrooms */}
        <div>
          <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
            Visitor's Allowed
          </p>
          <div className="grid grid-cols-1 gap-4">
            <button
              onClick={() => handleButtonClick('Yes')}
              className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'Yes' ? 'bg-gray-100' : ''}`}
            >
              Yes
            </button>
            <button
              onClick={() => handleButtonClick('No')}
              className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'No' ? 'bg-gray-100' : ''}`}
            >
              No
            </button>
          </div>
          
          <div className="mt-[55px]"></div>
          <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
            Dining facility
          </p>
          <div className="grid grid-cols-1 gap-4">
            <button
              onClick={() => handleButtonClick('Yes')}
              className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'Yes' ? 'bg-gray-100' : ''}`}
            >
              Yes
            </button>
            <button
              onClick={() => handleButtonClick('No')}
              className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'No' ? 'bg-gray-100' : ''}`}
            >
              No
            </button>
          </div>
        </div>


        <div>
          <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
            Parking
          </p>
          <div className="grid grid-cols-1 gap-4">
            <button
              onClick={() => handleButtonClick('Two Wheeler')}
              className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'Two Wheeler' ? 'bg-gray-100' : ''}`}
            >
              Two Wheeler
            </button>
            <button
              onClick={() => handleButtonClick('Four Wheeler')}
              className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'Four Wheeler' ? 'bg-gray-100' : ''}`}
            >
              Four Wheeler
            </button>
          </div>
          
          <div className="mt-[55px]"></div>
          <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
          Electricity
          </p>
          <div className="grid grid-cols-1 gap-4">
            <button
              onClick={() => handleButtonClick('Included')}
              className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'Included' ? 'bg-gray-100' : ''}`}
            >
              Included
            </button>
            <button
              onClick={() => handleButtonClick('Excluded')}
              className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'Excluded' ? 'bg-gray-100' : ''}`}
            >
              Excluded
            </button>
          </div>
        </div>


        <div>
          <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
          Furnished
          </p>
          <div className="grid grid-cols-1 gap-4">
            <button
              onClick={() => handleButtonClick('Furnished')}
              className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'Furnished' ? 'bg-gray-100' : ''}`}
            >
              Furnished
            </button>
            <button
              onClick={() => handleButtonClick('Semi-furnished')}
              className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'Semi-furnished' ? 'bg-gray-100' : ''}`}
            >
              Semi-furnished
            </button>
          </div>
          
          <div className="mt-[55px]"></div>
          <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
          Sharing
          </p>
          <div className="grid grid-cols-1 gap-4">
            <button
              onClick={() => handleButtonClick('Single Sharing')}
              className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'Single Sharing' ? 'bg-gray-100' : ''}`}
            >
              Single Sharing
            </button>
            <button
              onClick={() => handleButtonClick('Double Sharing')}
              className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'Double Sharing' ? 'bg-gray-100' : ''}`}
            >
              Double Sharing
            </button>
            
            <button
              onClick={() => handleButtonClick('Three Sharing')}
              className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'Three Sharing' ? 'bg-gray-100' : ''}`}
            >
              Three Sharing
            </button>
            <button
              onClick={() => handleButtonClick('Four Sharing')}
              className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${activeButton === 'Four Sharing' ? 'bg-gray-100' : ''}`}
            >
              Four Sharing
            </button>
          </div>
        </div>


        
          </div>

          {/* Areas of Interest Section */}
          <div className="flex flex-col pt-[150px] w-full">
            <h1 className="text-[18px] md:text-2xl font-bold mb-4 text-gray-600 text-left">
              Interests
            </h1>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 w-full">
              {[
                { name: "Fitness", image: fitness },
                { name: "Travel Freak", image: travel },
                { name: "Alcoholic Party", image: alcohol },
                { name: "Animal", image: party },
                { name: "Sports", image: sport },
                { name: "Reading", image: read },
                { name: "Video Games", image: video },
                { name: "Singing", image: sing },
                { name: "Dancing", image: dance },
                { name: "Food Explorer", image: food },
              ].map((interest, index) => (
                <div key={index} className="flex flex-col items-center">
                  <button
                    onClick={() => handleClick(index)}
                    className={`w-[60px] h-[60px] sm:w-[70px] sm:h-[70px] md:w-[80px] md:h-[80px] bg-[#FCF6BD] rounded-full mb-2 flex items-center justify-center ${
                      selected === index ? "border-[2px] border-gray-500" : ""
                    }`}
                  >
                    <img
                      src={interest.image}
                      alt={interest.name}
                      className="w-[40px] h-[40px] sm:w-[50px] sm:h-[50px] md:w-[60px] md:h-[60px] object-contain"
                    />
                  </button>
                  <h2 className="text-xs sm:text-sm md:text-sm text-center text-gray-600">
                    {interest.name}
                  </h2>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>

      <div className="flex justify-center mt-[140px]">
        <textarea
          placeholder="Description"
          value={description}
          onChange={handleDescriptionChange}
          maxLength={800} // Set the character limit to 800
          className="w-[calc(80%+45px)] h-[250px] border border-gray-300 rounded-[20px] outline-none resize-none font-light text-[18px] md:text-[25px] text-gray-600 p-6"
          rows="4"
        ></textarea>
      </div>

      <div className="flex justify-center mt-[100px] mb-[100px]">
        <button className="bg-[#A9DEF9] font-normal w-[300px] md:w-[400px] h-[60px] rounded-[60px] transition duration-200 ease-in-out text-[18px] md:text-[25px] border-b-[5px] border-r-4 border-gray-300">
          Submit
        </button>
      </div>
    </>
  );
}

export default RoomLisitngForm;
