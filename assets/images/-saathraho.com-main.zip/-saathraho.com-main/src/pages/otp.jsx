import React, { useState, useEffect } from 'react';
import Close from "../assets/closeicon.svg";
import Logo from "../assets/Logo.svg";
import { useLocation, useNavigate } from 'react-router-dom';

const OTP1 = () => {
  const [otp, setOtp] = useState(new Array(5).fill(""));
  const [timer, setTimer] = useState(60);
  const [resendAvailable, setResendAvailable] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  // Accessing email passed from SignupForm
  const { fullName } = location.state || {};
  const { email } = location.state || {};
  const { password } = location.state || {};
  const { phoneNo } = location.state || {};

  const handleChange = (element, index) => {
    if (isNaN(element.value)) return; // Prevent non-numeric input
    const newOtp = [...otp];
    newOtp[index] = element.value; 
    setOtp(newOtp);

    // Move focus to the next input if it's not empty
    if (element.value && element.nextSibling) {
      element.nextSibling.focus();
    }
  };

  const handleSubmit = async () => {
    try {
      const response = await fetch("http://localhost:8000/api/verify-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, otp: otp.join("") })
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();

      if (data.success) {
        alert("OTP verified successfully!");
        navigate("/home"); // Navigate to home on successful verification
      } else {
        alert("Invalid OTP, please try again.");
        setOtp(new Array(5).fill("")); // Clear OTP inputs
        document.querySelector('input').focus(); // Focus on the first input again
      }
    } catch (error) {
      console.error("Error verifying OTP:", error);
      alert("An error occurred while verifying the OTP. Please try again later.");
    }
  };

  const handleResend = async () => {
    try {
      setOtp(new Array(5).fill("")); // Reset OTP input fields
      setTimer(60); // Reset the timer
      setResendAvailable(false); // Disable the resend button

      // Call the signup API to resend the OTP
      const response = await fetch("http://localhost:8000/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: fullName,
          email: email,
          password: password,
          phoneNo: phoneNo,
          
        }),
      });

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      alert("A new OTP has been sent to your email!");
      document.querySelector('input').focus(); // Focus on the first input after resending

    } catch (error) {
      console.error("Error resending OTP:", error);
      alert("An error occurred while resending the OTP. Please try again later.");
    }
  };

  useEffect(() => {
    const countdown = setInterval(() => {
      if (timer > 0) {
        setTimer((prevTimer) => prevTimer - 1);
      } else {
        setResendAvailable(true); // Enable resend button after timer ends
      }
    }, 1000);

    return () => clearInterval(countdown); // Cleanup on unmount
  }, [timer]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-300 font-poppins overflow-hidden md:overflow-auto">
      <div className="bg-white rounded-2xl p-6 sm:p-8 w-[90%] sm:w-[500px] h-auto sm:h-[500px] shadow-lg flex flex-col">
        <div className="flex justify-between items-center">
          <div className="logo">
            <img src={Logo} alt="Logo" className="w-10 h-10" />
          </div>
          <button className="text-gray-400 hover:text-gray-600" onClick={() => navigate(-1)}>
            <img src={Close} alt="Close" className='h-8 w-8' />
          </button>
        </div>

        <h2 className="text-center text-xl sm:text-2xl font-semibold mt-4">OTP Verification</h2>
        <p className="text-center text-xs sm:text-sm text-gray-500 my-4 relative top-6">
          Check your notification/Email for your OTP
        </p>

        <div className="flex justify-center gap-4 mb-4 mt-4 relative top-6">
          {otp.map((data, index) => (
            <input
              key={index}
              type="text"
              className="w-12 h-12 sm:w-14 sm:h-14 border border-gray-300 text-center rounded-md text-xl focus:outline-none focus:ring-2 focus:ring-purple-400"
              maxLength="1"
              value={data}
              onChange={(e) => handleChange(e.target, index)}
              onFocus={(e) => e.target.select()}
            />
          ))}
        </div>

        <button
          className="mt-6 w-full bg-[#E4C1F9] text-gray-500 py-2 rounded-md transition relative top-[70px] sm:top-12"
          onClick={handleSubmit}
        >
          Submit OTP
        </button>

        <p className="text-[8px] sm:text-[9px] text-gray-400 text-center sm:mt-4 md:mt-[20px] mt-[30px] relative left-[-11px] sm:left-[-31px] top-[-50px]">
          By Tapping Submit OTP, you are accepting terms & conditions, Legal 
          <span className='md:left-0 relative left-[-114px]'> Notice and</span>
          <span className='relative md:left[-145px] left-[-58px] md:top-0 top-[-12px]'>
            <br /> privacy policy.
          </span>
        </p>

        <div className="text-center mt-6">
          <span className="text-gray-500">{timer > 0 ? `00:${timer < 10 ? `0${timer}` : timer}` : "00:00"}</span>
        </div>

        <div className="text-center mt-6">
          <p className="text-gray-500">
            Didn’t get OTP?{" "}
            <button
              className={`font-medium ${resendAvailable ? 'text-gray-500' : 'text-gray-200 cursor-not-allowed'}`}
              onClick={handleResend}
              disabled={!resendAvailable}
            >
              Resend Now
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default OTP1;
