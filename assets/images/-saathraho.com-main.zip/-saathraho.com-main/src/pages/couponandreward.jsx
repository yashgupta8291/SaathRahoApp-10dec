import React from 'react'
// import Images from "../assets/Image.svg";
// import dotted from "../assets/dotted.svg";
// import NavBar from "../components/navbar";
import CardGrid from "../components/cardgrid";

function couponandreward() {
  return (
    <div>
      {/* <img src={Images} alt="" className='h-[700px] w-[1000px] relative top-[50px] left-[300px]' />
      <img src={dotted} alt="" className='h-[550px] w-[900px] relative top-[-575px] left-[700px]' /> */}
      {/* <NavBar/> */}
      <CardGrid/>
    </div>
  )
}

export default couponandreward