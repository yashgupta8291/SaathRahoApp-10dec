import React, { useState } from "react";
import NavBar from "../components/navbar";
import fitness from "../assets/fitness.svg";
import travel from "../assets/travel.svg";
import alcohol from "../assets/alcohol.svg";
import party from "../assets/party.svg";
import sport from "../assets/sport.svg";
import read from "../assets/read.svg";
import video from "../assets/video.svg";
import sing from "../assets/sing.svg";
import dance from "../assets/dance.svg";
import food from "../assets/food.svg";
import upload from "../assets/upload.svg";
import { useForm } from "react-hook-form";
import axios from "axios";
function BhojanalayForm() {
	const [activeButton, setActiveButton] = useState(null);
	const { register, handleSubmit, setValue, watch } =
		useForm();
	// Function to handle button click

	const [description, setDescription] = useState("");

	const [image, setImage] = useState(null); // to store the selected image file
	const [imageUrl, setImageUrl] = useState("");
	const backendurl = import.meta.env.VITE_URL;
	const handleImageChange = (e) => {
		setImage(e.target.files[0]);
	};

	const uploadImage = async () => {
		const formData = new FormData();
		formData.append("file", image);
		formData.append("upload_preset", "your upload present"); // replace with your actual upload preset

		try {
			const response = await fetch(
				`https://api.cloudinary.com/v1_1/cloud name/image/upload`,
				{
					method: "POST",
					body: formData,
				}
			);
			const data = await response.json();
			setImageUrl(data.secure_url); // the image URL returned from Cloudinary
			console.log("image in cloudinary", data);
		} catch (error) {
			console.error("Error uploading image:", error);
		}
	};

	const [selected, setSelected] = useState(null);

	const onSubmit = async (data) => {
		console.log(data);
		const res = await axios.post(
			`${backendurl}/Createbhojnalayas`,
			{
				...data,
				BhojnalayaImages: JSON.stringify(imageUrl),
			},
			{
				headers: {
					"Content-Type": "application/json",
				},
			}
		);
		console.log(res.data);
	};
	const handleButtonClick = (name, value) => {
		setValue(name, value);
	};
	return (
		<>
			<NavBar />
			<div className="relative flex flex-col items-center justify-center pt-[300px] pb-8 h-auto text-center z-10">
				<h1 className="text-xl md:text-[40px] font-bold mb-2 text-gray-600">
					Add Your Bhojanalay Details
				</h1>
				<p className="text-md md:text-2xl text-gray-600">
					so anyone can connect with you
				</p>
			</div>
			<form onSubmit={handleSubmit(onSubmit)}>
				<div className="flex flex-col md:flex-row justify-center gap-x-[200px] gap-y-[100px] px-4 pt-[200px]">
					<div className="space-y-6 w-full  md:w-[1000px] max-w-lg">
						{/* Your Name */}
						<div>
							<p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins ">
								Your Name
							</p>
							<input
								type="text"
								placeholder="Full Name"
								className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600 "
								{...register("BhojnalayaName")}
							/>
						</div>

						{/* Location */}
						<div className="relative">
							<p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
								Location
							</p>
							<div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
								<svg
									xmlns="http://www.w3.org/2000/svg"
									className="sm:h-6 sm:w-6 h-5 w-5 text-gray-600 relative top-[-18px] sm:top-[-8px]"
									fill="currentColor"
									viewBox="0 0 24 24"
								>
									<path d="M12 2C6.48 2 2 6.48 2 12c0 5.5 10 10 10 10s10-4.5 10-10c0-5.52-4.48-10-10-10zm0 14c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4z" />
								</svg>
							</div>
							<textarea
								placeholder="Add location..."
								className="w-full pl-10 p-4 h-32 border border-gray-300 rounded-[20px] outline-none resize-none font-light text-[18px] md:text-[25px] text-gray-600"
								rows="4"
								{...register("location")}
							></textarea>
						</div>

						{/* Hometown */}
						<div>
							<p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
								Monthly Thali Charges 1 Time
							</p>
							<input
								type="text"
								placeholder="₹ eg: 00, 500, 800, 1000......."
								className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
								{...register("MonthlyCharge1")}
							/>
						</div>

						<div>
							<p className="text-gray-600 font-semibold mb-2 text-[20px] md:text-[25px] font-poppins">
								Monthly Thali Charges 2 Time
							</p>
							<input
								type="text"
								placeholder="₹ 00, 500, 800, 1000......."
								className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
								{...register("MonthlyCharge2")}
							/>
						</div>

						<div>
							<p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
								Timings
							</p>
							<input
								type="text"
								placeholder="eg: 6am - 10pm, 10pm - 12pm......."
								className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
								{...register("Timings")}
							/>
						</div>

						<div>
							<p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
								Price of Thali
							</p>
							<input
								type="text"
								placeholder="eg: 60/- , 80/- , 100/- ......."
								className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
								{...register("PriceOfThali")}
							/>
						</div>

						{/* Upload Image Section */}
						<div className="relative pt-[50px]">
							<div
								className="upload-field border-dashed p-6 text-center cursor-pointer sm:bg-[#F7F7F7] bg-gray-200 rounded-[20px]"
								style={{ width: "100%", height: "400px" }}
							>
								<input
									type="file"
									accept="image/*"
									multiple
									style={{ display: "none" }}
									id="upload-input"
									onChange={(e) => {
										const file = e.target.files[0];
										if (file) {
											const reader = new FileReader();
											reader.onloadend = () => {
												setImage(reader.result); // Save base64 image data
											};
											reader.readAsDataURL(file);
										}
									}}
									{...register("BhojnalayaImages")}
								/>
								<label
									htmlFor="upload-input"
									className="text-gray-600 font-semibold text-[18px] md:text-[20px]"
								>
									<img
										src={upload}
										alt=""
										className="w-[70%] mx-auto h-[100px]"
									/>
								</label>
								{image ? (
									<img
										src={image}
										alt="Uploaded"
										className="mt-4 max-w-full h-[250px] rounded-lg"
									/>
								) : (
									<img
										src={upload}
										alt="Upload Icon"
										className="w-0 h-0 mx-auto"
									/>
								)}
							</div>
						</div>
					</div>

					{/* Right section */}
					<div className="space-y-6 w-full md:max-w-lg pt-[10px]">
						<div className="grid grid-cols-1 md:grid-cols-2 gap-8">
							<div>
								<p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[23px] font-poppins">
									Parcel of Food
								</p>
								<div className="grid grid-cols-1 gap-4">
									<button
										type="button"
										onClick={() =>
											handleButtonClick(
												"ParcelOfFood",
												"Deliver"
											)
										}
										className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
											activeButton === "Deliver"
												? "bg-gray-100"
												: ""
										}`}
									>
										Deliver
									</button>
									<button
										type="button"
										onClick={() =>
											handleButtonClick(
												"ParcelOfFood",
												"Takeaway"
											)
										}
										className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
											activeButton === "Takeaway"
												? "bg-gray-100"
												: ""
										}`}
									>
										Takeaway
									</button>
								</div>

								<div className="mt-[60px]">
									<p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
										Parking
									</p>
									<div className="grid grid-cols-1 gap-4">
										<button
											type="button"
											onClick={() =>
												handleButtonClick("Parking", "Yes")
											}
											className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
												activeButton === "Yes"
													? "bg-gray-100"
													: ""
											}`}
										>
											Yes
										</button>
										<button
											type="button"
											onClick={() =>
												handleButtonClick("Parking", "No")
											}
											className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
												activeButton === "No"
													? "bg-gray-100"
													: ""
											}`}
										>
											No
										</button>
									</div>
								</div>
							</div>

							<div>
								<p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
									Veg or Non-Veg
								</p>
								<div className="grid grid-cols-1 gap-4">
									<button
										type="button"
										onClick={() =>
											handleButtonClick(
												"VegOrNonVeg",
												"Veg"
											)
										}
										className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
											activeButton === "Veg"
												? "bg-gray-100"
												: ""
										}`}
									>
										Veg
									</button>
									<button
										type="button"
										onClick={() =>
											handleButtonClick(
												"VegOrNonVeg",
												"Non-Veg"
											)
										}
										className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
											activeButton === "Non-Veg"
												? "bg-gray-100"
												: ""
										}`}
									>
										Non-Veg
									</button>
								</div>

								<div className="mt-[55px]"></div>
								<p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
									Any Special Thali
								</p>
								<div className="grid grid-cols-1 gap-4">
									<button
										type="button"
										onClick={() =>
											handleButtonClick(
												"SpecialThali",
												"Yes"
											)
										}
										className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
											activeButton === " Yes"
												? "bg-gray-100"
												: ""
										}`}
									>
										Yes
									</button>
									<button
										type="button"
										onClick={() =>
											handleButtonClick(
												"SpecialThali",
												"No"
											)
										}
										className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
											activeButton === " No"
												? "bg-gray-100"
												: ""
										}`}
									>
										No
									</button>
								</div>
							</div>
						</div>

						{/* Areas of Interest Section */}
						<div className="flex flex-col pt-[60px] w-full">
							<h1 className="text-[18px] md:text-2xl font-bold mb-4 text-gray-600 text-left">
								Interests
							</h1>

							<div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 w-full">
								{[
									{ name: "Fitness", image: fitness },
									{ name: "Travel Freak", image: travel },
									{
										name: "Alcoholic Party",
										image: alcohol,
									},
									{ name: "Animal", image: party },
									{ name: "Sports", image: sport },
									{ name: "Reading", image: read },
									{ name: "Video Games", image: video },
									{ name: "Singing", image: sing },
									{ name: "Dancing", image: dance },
									{ name: "Food Explorer", image: food },
								].map((interest, index) => (
									<div
										key={index}
										className="flex flex-col items-center"
									>
										<button
											type="button"
											onClick={() =>
												handleButtonClick(
													"Amenities",
													interest.name
												)
											}
											className={`w-[60px] h-[60px] sm:w-[70px] sm:h-[70px] md:w-[80px] md:h-[80px] bg-[#FCF6BD] rounded-full mb-2 flex items-center justify-center ${
												selected === index
													? "border-[2px] border-gray-500"
													: ""
											}`}
										>
											<img
												src={interest.image}
												alt={interest.name}
												className="w-[40px] h-[40px] sm:w-[50px] sm:h-[50px] md:w-[60px] md:h-[60px] object-contain"
											/>
										</button>
										<h2 className="text-xs sm:text-sm md:text-sm text-center text-gray-600">
											{interest.name}
										</h2>
									</div>
								))}
							</div>
						</div>
						{/* Description Box */}
						<div className="flex justify-center mt-[100px] mb-[100px] sm:pt-[70px] sm:mb-[60px]">
							<textarea
								placeholder="Description"
								maxLength={800}
								className="w-full sm:w-[90%] md:w-[80%] lg:w-[100%] h-[250px] sm:h-[300px] md:h-[380px] border border-gray-300 rounded-[20px] outline-none resize-none font-light text-[18px] md:text-[25px] text-gray-600 p-6"
								rows="4"
								{...register("Description")}
							></textarea>
						</div>
					</div>
				</div>

				<div className="flex justify-center mt-[100px] mb-[100px]">
					<button
						className="bg-[#A9DEF9] font-normal w-[300px] md:w-[400px] h-[60px] rounded-[60px] transition duration-200 ease-in-out text-[18px] md:text-[25px] border-b-[5px] border-r-4 border-gray-300"
						type="submit"
					>
						Submit
					</button>
				</div>
			</form>
		</>
	);
}

export default BhojanalayForm;
