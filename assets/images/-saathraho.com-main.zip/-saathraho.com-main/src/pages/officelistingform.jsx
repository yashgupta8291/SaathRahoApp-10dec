import React, { useState } from "react";
import NavBar from "../components/navbar";
import fitness from "../assets/fitness.svg";
import travel from "../assets/park.svg";
import alcohol from "../assets/swim.svg";
import party from "../assets/water.svg";
import sport from "../assets/heater.svg";
import read from "../assets/tv.svg";
import video from "../assets/bed.svg";
import sing from "../assets/ac.svg";
import dance from "../assets/hospital.svg";
import food from "../assets/market.svg";
import upload from "../assets/upload.svg";

function OfficeLisitngForm() {
  const [activeButton, setActiveButton] = useState(null);
  

  // Function to handle button click
  const handleButtonClick = (buttonName) => {
    setActiveButton(buttonName);
  };
  

  const [selectedGender, setSelectedGender] = useState("");
  const [description, setDescription] = useState("");
  const [title, setTitle] = useState("");

  const [image, setImage] = useState(null);

  const handleGenderSelect = (gender) => {
    setSelectedGender(gender);
  };

  const handleTitleChange = (e) => {
    const value = e.target.value;
    if (value.length <= 25) {
      setTitle(value);
    }
  };

  const [selected, setSelected] = useState(null);

  const handleClick = (index) => {
    setSelected(index);
  };

  const handleDescriptionChange = (e) => {
    const value = e.target.value;
    if (value.length <= 800) {
      // Limit to 800 characters
      setDescription(value);
    }
  };

  return (
    <>
      <NavBar />
      <div className="relative flex flex-col items-center justify-center pt-[300px] pb-8 h-auto text-center z-10">
        <h1 className="text-xl md:text-[40px] font-bold mb-2 text-gray-600">
          Add Your Office space Details
        </h1>
        <p className="text-md md:text-2xl text-gray-600">
          so anyone can connect with you
        </p>
      </div>

      <div className="flex flex-col md:flex-row justify-center gap-x-[200px] gap-y-[100px] px-4 pt-[200px]">
        <div className="space-y-6 w-full  md:w-[1000px] max-w-lg">
          {/* Your Name */}
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Your Name
            </p>
            <input
              type="text"
              placeholder="Full Name"
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          {/* Location */}
          <div className="relative">
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Location
            </p>
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="sm:h-6 sm:w-6 h-5 w-5 text-gray-600 relative top-[-18px] sm:top-[-8px]"
                fill="currentColor"
                viewBox="0 0 24 24"
              >
                <path d="M12 2C6.48 2 2 6.48 2 12c0 5.5 10 10 10 10s10-4.5 10-10c0-5.52-4.48-10-10-10zm0 14c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4z" />
              </svg>
            </div>
            <textarea
              placeholder="Add location..."
              className="w-full pl-10 p-4 h-32 border border-gray-300 rounded-[20px] outline-none resize-none font-light text-[18px] md:text-[25px] text-gray-600"
              rows="4"
            ></textarea>
          </div>

          {/* Hometown */}
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Monthly Rent
            </p>
            <input
              type="text"
              placeholder="e.g., Mumbai, Bhopal......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          {/* Room Preference */}
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[20px] md:text-[25px] font-poppins">
              Monthly Maintenance
            </p>
            <input
              type="text"
              placeholder="₹ 00, 500, 800, 1000......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          {/* Language Preference */}
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Floor No.
            </p>
            <input
              type="text"
              placeholder="eg: 1st floor, 2nd floor......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Total Floor
            </p>
            <input
              type="text"
              placeholder="eg: 1st floor, 2nd floor......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Build-up Carpet
            </p>
            <input
              type="text"
              placeholder="eg: 600sq, 800sq, 1000sq......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Facing
            </p>
            <input
              type="text"
              placeholder="eg: North, South, East......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Deposit
            </p>
            <input
              type="text"
              placeholder="eg: 1 month, 15 Days......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          {/* Upload Image Section */}
          <div className="relative pt-[50px]">
            <div
              className="upload-field border-dashed p-6 text-center cursor-pointer bg-[#F7F7F7] rounded-[20px]"
              style={{ width: "100%", height: "400px" }}
            >
              <input
                type="file"
                accept="image/*"
                multiple
                style={{ display: "none" }}
                id="upload-input"
                onChange={(e) => {
                  const file = e.target.files[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onloadend = () => {
                      setImage(reader.result); // Save base64 image data
                    };
                    reader.readAsDataURL(file);
                  }
                }}
              />
              <label
                htmlFor="upload-input"
                className="text-gray-600 font-semibold text-[18px] md:text-[20px]"
              >
                <img
                  src={upload}
                  alt=""
                  className="w-[70%] mx-auto h-[100px]"
                />
              </label>
              {image ? (
                <img
                  src={image}
                  alt="Uploaded"
                  className="mt-4 max-w-full h-[250px] rounded-lg"
                />
              ) : (
                <img
                  src={upload}
                  alt="Upload Icon"
                  className="w-0 h-0 mx-auto"
                />
              )}
            </div>
          </div>
        </div>

        {/* Right section */}
        <div className="space-y-6 w-full md:max-w-lg pt-[10px]">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Bachelor's Allowed */}
            <div>
              <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[23px] font-poppins">
                Parking Available
              </p>
              <div className="grid grid-cols-1 gap-4">
                <button
                  onClick={() => handleButtonClick("4 Wheeler")}
                  className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
                    activeButton === "4 Wheeler" ? "bg-gray-100" : ""
                  }`}
                >
                  4 Wheeler
                </button>
                <button
                  onClick={() => handleButtonClick("2 Wheeler")}
                  className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
                    activeButton === "2 Wheeler" ? "bg-gray-100" : ""
                  }`}
                >
                  2 Wheeler
                </button>
                <button
                  onClick={() => handleButtonClick("All Vehicle")}
                  className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
                    activeButton === "All Vehicle" ? "bg-gray-100" : ""
                  }`}
                >
                  All Vehicle
                </button>
                <button
                  onClick={() => handleButtonClick("None")}
                  className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
                    activeButton === "None" ? "bg-gray-100" : ""
                  }`}
                >
                  None
                </button>
              </div>

              {/* Listed by */}
              <div className="mt-[60px]">
                <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
                  No. of Bathroom
                </p>
                <div className="grid grid-cols-1 gap-4">
                  <button
                    onClick={() => handleButtonClick("1 Bathroom")}
                    className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
                      activeButton === "1 Bathroom" ? "bg-gray-100" : ""
                    }`}
                  >
                    1 Bathroom
                  </button>
                  <button
                    onClick={() => handleButtonClick("2 Bathroom")}
                    className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
                      activeButton === "2 Bathroom" ? "bg-gray-100" : ""
                    }`}
                  >
                    2 Bathroom
                  </button>
                  <button
                    onClick={() => handleButtonClick("3 Bathroom")}
                    className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
                      activeButton === "3 Bathroom" ? "bg-gray-100" : ""
                    }`}
                  >
                    3 Bathroom
                  </button>
                </div>
              </div>
            </div>

            <div>
              <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
                No. of Cabins?
              </p>
              <div className="grid grid-cols-1 gap-4">
                <button
                  onClick={() => handleButtonClick("1BHK")}
                  className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
                    activeButton === "1BHK" ? "bg-gray-100" : ""
                  }`}
                >
                  1BHK
                </button>
                <button
                  onClick={() => handleButtonClick("2BHK")}
                  className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
                    activeButton === "2BHK" ? "bg-gray-100" : ""
                  }`}
                >
                  2BHK
                </button>
                <button
                  onClick={() => handleButtonClick("3BHK")}
                  className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
                    activeButton === "3BHK" ? "bg-gray-100" : ""
                  }`}
                >
                  3BHK
                </button>
                <button
                  onClick={() => handleButtonClick("4+BHK")}
                  className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
                    activeButton === "4+BHK" ? "bg-gray-100" : ""
                  }`}
                >
                  4+BHK
                </button>
              </div>

              <div className="mt-[55px]"></div>
              <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
                Furnished
              </p>
              <div className="grid grid-cols-1 gap-4">
                <button
                  onClick={() => handleButtonClick("Furnished")}
                  className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
                    activeButton === "Furnished" ? "bg-gray-100" : ""
                  }`}
                >
                  Furnished
                </button>
                <button
                  onClick={() => handleButtonClick("Semi-furnished")}
                  className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
                    activeButton === "Semi-furnished" ? "bg-gray-100" : ""
                  }`}
                >
                  Semi-furnished
                </button>
                <button
                  onClick={() => handleButtonClick("Non-furnished")}
                  className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
                    activeButton === "Non-furnished" ? "bg-gray-100" : ""
                  }`}
                >
                  Non-furnished
                </button>
              </div>
            </div>

            <div>
              <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
                Listed by
              </p>
              <div className="grid grid-cols-1 gap-4">
                <button
                  onClick={() => handleButtonClick("Owner")}
                  className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
                    activeButton === "Owner" ? "bg-gray-100" : ""
                  }`}
                >
                  Owner
                </button>
                <button
                  onClick={() => handleButtonClick("Rental")}
                  className={`border p-4 rounded-[20px] w-full text-[18px] md:text-[25px] font-light border-b-4 border-r-4 border-gray-300 shadow-md ${
                    activeButton === "Rental" ? "bg-gray-100" : ""
                  }`}
                >
                  Builder
                </button>
              </div>
            </div>
          </div>

          {/* Areas of Interest Section */}
          <div className="flex flex-col pt-[150px] w-full">
            <h1 className="text-[18px] md:text-2xl font-bold mb-4 text-gray-600 text-left">
              Interests
            </h1>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 w-full">
              {[
                { name: "Gym", image: fitness },
                { name: "Park", image: travel },
                { name: "Swimming Pool", image: alcohol },
                { name: "Water Purifier", image: party },
                { name: "Heater", image: sport },
                { name: "T.V.", image: read },
                { name: "Bed", image: video },
                { name: "A.C.", image: sing },
                { name: "Hospital Nearby", image: dance },
                { name: "Market", image: food },
              ].map((interest, index) => (
                <div key={index} className="flex flex-col items-center">
                  <button
                    onClick={() => handleClick(index)}
                    className={`w-[60px] h-[60px] sm:w-[70px] sm:h-[70px] md:w-[80px] md:h-[80px] bg-[#FCF6BD] rounded-full mb-2 flex items-center justify-center ${
                      selected === index ? "border-[2px] border-gray-500" : ""
                    }`}
                  >
                    <img
                      src={interest.image}
                      alt={interest.name}
                      className="w-[40px] h-[40px] sm:w-[50px] sm:h-[50px] md:w-[60px] md:h-[60px] object-contain"
                    />
                  </button>
                  <h2 className="text-xs sm:text-sm md:text-sm text-center text-gray-600">
                    {interest.name}
                  </h2>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-center mt-[140px]">
        <textarea
          placeholder="Description"
          value={description}
          onChange={handleDescriptionChange}
          maxLength={800} // Set the character limit to 800
          className="w-[calc(80%+45px)] h-[250px] border border-gray-300 rounded-[20px] outline-none resize-none font-light text-[18px] md:text-[25px] text-gray-600 p-6"
          rows="4"
        ></textarea>
      </div>

      <div className="flex justify-center mt-[100px] mb-[100px]">
        <button className="bg-[#A9DEF9] font-normal w-[300px] md:w-[400px] h-[60px] rounded-[60px] transition duration-200 ease-in-out text-[18px] md:text-[25px] border-b-[5px] border-r-4 border-gray-300">
          Submit
        </button>
      </div>
    </>
  );
}

export default OfficeLisitngForm;
