import React, { useState } from "react";
import dots from "../assets/dots.png";
import nomessage from "../assets/nomessage.png";
import send from "../assets/send.png";
import Navbar from "../components/Navbar";

function ChatPage() {
  const [selectedButton, setSelectedButton] = useState(null);
  const [selectedChat, setSelectedChat] = useState(null);

  // Separate state for dropdowns
  const [leftDropdownOpen, setLeftDropdownOpen] = useState(false); // Left dropdown state
  const [rightDropdownOpen, setRightDropdownOpen] = useState(false); // Right dropdown state

  // Function to toggle left dropdown and close right dropdown
  const toggleLeftDropdown = () => {
    setLeftDropdownOpen(!leftDropdownOpen);
    setRightDropdownOpen(false); // Close right dropdown if left opens
  };

  // Function to toggle right dropdown and close left dropdown
  const toggleRightDropdown = () => {
    setRightDropdownOpen(!rightDropdownOpen);
    setLeftDropdownOpen(false); // Close left dropdown if right opens
  };

  const handleButtonClick = (buttonName) => {
    setSelectedButton(buttonName);
  };

  const handleChatClick = (chatIndex) => {
    setSelectedChat(chatIndex);
  };

  // Sample chat data
  const chats = [
    {
      name: "Name of the person",
      message: "One line description..............",
      location: "Location",
      time: "Date of last message",
    },
    {
      name: "Name of the person",
      message: "One line description..............",
      location: "Location",
      time: "Date of last message",
    },
    {
      name: "Name of the person",
      message: "One line description..............",
      location: "Location",
      time: "Date of last message",
    },
    {
      name: "Name of the person",
      message: "One line description..............",
      location: "Location",
      time: "Date of last message",
    },
    {
      name: "Name of the person",
      message: "One line description..............",
      location: "Location",
      time: "Date of last message",
    },
    {
      name: "Name of the person",
      message: "One line description..............",
      location: "Location",
      time: "Date of last message",
    },
    {
      name: "Name of the person",
      message: "One line description..............",
      location: "Location",
      time: "Date of last message",
    },
    {
      name: "Name of the person",
      message: "One line description..............",
      location: "Location",
      time: "Date of last message",
    },
    {
      name: "Name of the person",
      message: "One line description..............",
      location: "Location",
      time: "Date of last message",
    },
    {
      name: "Name of the person",
      message: "One line description..............",
      location: "Location",
      time: "Date of last message",
    },
  ];

  return (
    <div className="font-poppins">
      <Navbar />
      <div className="h-[200px] bg-white"></div>

      {/* Chatbox container */}
      <div className="mx-auto w-[80%] h-[590px] border-2 border-black mt-[0px] mb-[50px] relative flex shadow-lg rounded-lg overflow-hidden top-[-70px]">
        {/* Left Section (40% Width) */}
        <div className="w-[40%] border-r border-gray-300 p-6 flex flex-col h-full">
          <div className="flex items-center justify-between">
            <h2 className="text-3xl font-medium">Chats</h2>
            <div className="rounded-full h-[35px] w-[35px] border border-black relative left-[-120px]"></div>
            <div className="flex items-center space-x-3">
              {/* Dots Icon (Left Section) */}
              <div className="relative">
                <img
                  src={dots}
                  alt="Options"
                  className="h-10 w-10 cursor-pointer"
                  onClick={toggleLeftDropdown} // Toggle left dropdown when dots are clicked
                />
                {/* Left Dropdown Menu */}
                {leftDropdownOpen && (
                  <div className="dropdown-content menu rounded-box z-[1] w-52 p-2 shadow absolute right-0 mt-1 bg-gray-100">
                    <ul>
                      <li>
                        <a href="#">Create New Chat</a>
                      </li>
                      <li>
                        <a href="#">Settings</a>
                      </li>
                      <li>
                        <a href="#">Help</a>
                      </li>
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </div>
          <div className="h-[1px] w-[480px] bg-black mt-4 mb-2 relative left-[-23px]"></div>

          {/* Button Group */}
          <div className="mt-4 flex space-x-4 text-xl">
            <button
              className={`${
                selectedButton === "All Chats" ? "bg-[#A9DEF9]" : ""
              } border-black rounded-[60px] h-[35px] w-[150px] border-[1px] shadow-sm`}
              onClick={() => handleButtonClick("All Chats")}
            >
              All Chats
            </button>
            <button
              className={`${
                selectedButton === "Important" ? "bg-[#A9DEF9]" : ""
              } border-black rounded-[60px] h-[35px] w-[150px] border-[1px] shadow-sm`}
              onClick={() => handleButtonClick("Important")}
            >
              Important
            </button>
            <button
              className={`${
                selectedButton === "Unread" ? "bg-[#A9DEF9]" : ""
              } border-black rounded-[60px] h-[35px] w-[150px] border-[1px] shadow-sm`}
              onClick={() => handleButtonClick("Unread")}
            >
              Unread
            </button>
          </div>

          {/* Line below the Unread button */}
          <div className="h-[1px] w-[480px] bg-black mt-6 mb-8 relative left-[-23px]"></div>

          {/* Chat List */}
          <div className="mt-4 overflow-y-auto flex-grow w-[460px] h-[80%] mb-8">
            {chats.map((chat, index) => (
              <div
                key={index}
                className={`flex items-center justify-between border-b py-4 cursor-pointer hover:bg-gray-50 ${
                  selectedChat === index ? "bg-gray-100" : ""
                }`}
                onClick={() => handleChatClick(index)}
              >
                <div className="flex items-center space-x-8">
                  {/* Avatar with Green Circle */}
                  <div className="relative h-[70px] w-[70px] bg-[#D58D8D] rounded-md">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="h-[30px] w-[30px] bg-[#22A173] rounded-full relative left-[35px] top-[20px]"></div>
                    </div>
                  </div>

                  {/* Chat Information */}
                  <div className="flex flex-col space-y-2">
                    <h3 className="text-md font-medium">{chat.name}</h3>
                    <p className="text-xs text-gray-500">{chat.message}</p>
                    <p className="text-[10px] text-gray-400">{chat.location}</p>
                  </div>
                </div>
                {/* Timestamp */}
                <div className="text-[8px] text-gray-400 relative top-[-20px] left-[-30px]">
                  {chat.time}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Section (60% Width) */}
        <div className="w-[60%] p-6 flex flex-col justify-between">
          {selectedChat !== null ? (
            <>
              {/* Header Section */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="h-[80px] w-[80px] rounded-full border border-black"></div>
                  <h2 className="text-xl font-medium">
                    {chats[selectedChat].name}
                  </h2>
                </div>
                {/* Dots Icon (Right Section) */}
                <div className="relative">
                  <img
                    src={dots}
                    alt="Options"
                    className="h-10 w-10 cursor-pointer"
                    onClick={toggleRightDropdown} // Toggle right dropdown when dots are clicked
                  />
                  {/* Right Dropdown Menu */}
                  {rightDropdownOpen && (
                    <div className="dropdown-content menu rounded-box z-[1] w-52 p-2 shadow absolute right-0 mt-1 bg-gray-100">
                      <ul>
                        <li>
                          <a href="#">View Profile</a>
                        </li>
                        <li>
                          <a href="#">Mute Notifications</a>
                        </li>
                        <li>
                          <a href="#">Delete Chat</a>
                        </li>
                      </ul>
                    </div>
                  )}
                </div>
              </div>
              <div className="w-[900px] border-b border-black my-4 relative left-[-23px]"></div>

              {/* Chat Content */}
              <div className="flex-1">{/* Add your chat messages here */}</div>

              {/* Input Section */}
              <div className="flex items-center space-x-4 mt-4">
                <input
                  type="text"
                  placeholder="Type a message..."
                  className="w-full h-[60px] px-4 rounded-full border-2 border-black focus:outline-none"
                />
                <button className="w-[70px] h-[60px] rounded-full bg-[#A9DEF9] border-2 border-black flex items-center justify-center">
                  <img src={send} alt="" className="h-[50%] w-[60%]" />
                </button>
              </div>
            </>
          ) : (
            // Empty state when no chat is selected
            <div className="flex flex-col items-center justify-center h-full">
              <img
                src={nomessage}
                alt="No messages"
                className="h-[550px] w-[710px] mb-4 relative"
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default ChatPage;
