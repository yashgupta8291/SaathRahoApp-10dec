import React, { useState } from "react";
import NavBar from "../components/navbar";
import fitness from "../assets/fitness.svg";
import travel from "../assets/travel.svg";
import alcohol from "../assets/alcohol.svg";
import party from "../assets/party.svg";
import sport from "../assets/sport.svg";
import read from "../assets/read.svg";
import video from "../assets/video.svg";
import sing from "../assets/sing.svg";
import dance from "../assets/dance.svg";
import food from "../assets/food.svg";

function RoommateForm() {
  const [selectedGender, setSelectedGender] = useState("");
  const [description, setDescription] = useState("");
  const [title, setTitle] = useState("");

  const [selected, setSelected] = useState(null);

  const handleClick = (index) => {
    setSelected(index);
  };

  const handleGenderSelect = (gender) => {
    setSelectedGender(gender);
  };

  const handleTitleChange = (e) => {
    const value = e.target.value;
    if (value.length <= 25) {
      setTitle(value);
    }
  };

  const handleDescriptionChange = (e) => {
    const value = e.target.value;
    if (value.length <= 800) {
      // Limit to 800 characters
      setDescription(value);
    }
  };

  return (
    <>
      <NavBar />
      <div className="relative flex flex-col items-center justify-center pt-[300px] pb-8 h-auto text-center z-10">
        <h1 className="text-xl md:text-[40px] font-bold mb-2 text-gray-600">
          Add Your Flat/Room Details
        </h1>
        <p className="text-md md:text-2xl text-gray-600">
          so anyone can connect with you
        </p>
      </div>

      <div className="flex flex-col md:flex-row justify-center gap-x-[200px] gap-y-[100px] px-4 pt-[200px]">
        <div className="space-y-6 w-full  md:w-[1000px] max-w-lg">
          {/* Your Name */}
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Your Name
            </p>
            <input
              type="text"
              placeholder="Full Name"
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          {/* Location */}
          <div className="relative">
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Location
            </p>
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="sm:h-6 sm:w-6 h-5 w-5 text-gray-600 relative top-[-18px] sm:top-[-8px]"
                fill="currentColor"
                viewBox="0 0 24 24"
              >
                <path d="M12 2C6.48 2 2 6.48 2 12c0 5.5 10 10 10 10s10-4.5 10-10c0-5.52-4.48-10-10-10zm0 14c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4z" />
              </svg>
            </div>
            <textarea
              placeholder="Add location..."
              className="w-full pl-10 p-4 h-32 border border-gray-300 rounded-[20px] outline-none resize-none font-light text-[18px] md:text-[25px] text-gray-600"
              rows="4"
            ></textarea>
          </div>

          {/* Hometown */}
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Hometown
            </p>
            <input
              type="text"
              placeholder="e.g., Mumbai, Bhopal......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          { /* Budget */}
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Budget
            </p>
            <input
              type="text"
              placeholder="e.g., 500/- , 1000/- , 1500/- ......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          {/* Room Preference */}
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[20px] md:text-[25px] font-poppins">
              Room Preference
            </p>
            <input
              type="text"
              placeholder="e.g., 1BHK, PG, Hostel......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          {/* Language Preference */}
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Language Preference
            </p>
            <input
              type="text"
              placeholder="e.g., Hindi, English......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>
        </div>

        <div className="space-y-6 w-full md:max-w-lg gap-y-[100px] pt-[10px]">
          {/* Gender Preference */}
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Gender Preference
            </p>
            <div className="flex space-x-4">
              <button
                onClick={() => handleGenderSelect("Male")}
                className={`border p-2 rounded-[20px] w-1/2 h-19 text-[18px] md:text-[25px] font-light transition duration-200 ease-in-out ${
                  selectedGender === "Male"
                    ? "bg-gray-100 border-gray-400 shadow-md"
                    : "border-gray-300 shadow-md"
                }`}
              >
                Male
              </button>
              <button
                onClick={() => handleGenderSelect("Female")}
                className={`border p-2 rounded-[20px] w-1/2 h-19 text-[18px] md:text-[25px] font-light transition duration-200 ease-in-out ${
                  selectedGender === "Female"
                    ? "bg-gray-100 border-gray-400 shadow-md"
                    : "border-gray-300 shadow-md"
                }`}
              >
                Female
              </button>
            </div>
          </div>

          {/* Occupation */}
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Occupation
            </p>
            <input
              type="text"
              placeholder="e.g., Student, Corporate Job......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          {/* Move-In Date */}
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Move-In Date
            </p>
            <input
              type="date"
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          {/* Location Preference */}
          <div>
            <p className="text-gray-600 font-semibold mb-2 text-[18px] md:text-[25px] font-poppins">
              Location Preference
            </p>
            <input
              type="text"
              placeholder="e.g., Bangalore, Pune......."
              className="w-full p-4 h-19 border border-gray-300 rounded-[20px] outline-none font-light text-[18px] md:text-[25px] text-gray-600"
            />
          </div>

          {/* Areas of Interest Section */}
          <div className="flex flex-col pt-[150px] w-full">
            <h1 className="text-[18px] md:text-2xl font-bold mb-4 text-gray-600 text-left">
              Interests
            </h1>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 w-full">
              {[
                { name: "Fitness", image: fitness },
                { name: "Travel Freak", image: travel },
                { name: "Alcoholic Party", image: alcohol },
                { name: "Animal", image: party },
                { name: "Sports", image: sport },
                { name: "Reading", image: read },
                { name: "Video Games", image: video },
                { name: "Singing", image: sing },
                { name: "Dancing", image: dance },
                { name: "Food Explorer", image: food },
              ].map((interest, index) => (
                <div key={index} className="flex flex-col items-center">
                  <button
                    onClick={() => handleClick(index)}
                    className={`w-[60px] h-[60px] sm:w-[70px] sm:h-[70px] md:w-[80px] md:h-[80px] bg-[#FCF6BD] rounded-full mb-2 flex items-center justify-center ${
                      selected === index ? "border-[2px] border-gray-500" : ""
                    }`}
                  >
                    <img
                      src={interest.image}
                      alt={interest.name}
                      className="w-[40px] h-[40px] sm:w-[50px] sm:h-[50px] md:w-[60px] md:h-[60px] object-contain"
                    />
                  </button>
                  <h2 className="text-xs sm:text-sm md:text-sm text-center text-gray-600">
                    {interest.name}
                  </h2>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-center mt-[140px]">
        <textarea
          placeholder="Description"
          value={description}
          onChange={handleDescriptionChange}
          maxLength={800} // Set the character limit to 800
          className="w-[calc(80%+45px)] h-[250px] border border-gray-300 rounded-[20px] outline-none resize-none font-light text-[18px] md:text-[25px] text-gray-600 p-6"
          rows="4"
        ></textarea>
      </div>

      <div className="flex justify-center mt-[100px] mb-[100px]">
        <button className="bg-[#A9DEF9] font-normal w-[300px] md:w-[400px] h-[60px] rounded-[60px] transition duration-200 ease-in-out text-[18px] md:text-[25px] border-b-[5px] border-r-4 border-gray-300">
          Submit
        </button>
      </div>
    </>
  );
}

export default RoommateForm;
